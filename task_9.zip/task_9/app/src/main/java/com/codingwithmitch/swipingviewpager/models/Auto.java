package com.codingwithmitch.swipingviewpager.models;

import android.os.Parcel;
import android.os.Parcelable;

public class Auto implements Parcelable {

    private String title;
    private int image;
    private int serial_number;

    public Auto(String title, int image) {
        this.title = title;
        this.image = image;
        this.serial_number = serial_number;
    }

    public Auto(Auto product) {
        this.title = product.title;
        this.image = product.image;
        this.serial_number = product.serial_number;
    }


    protected Auto(Parcel in) {
        title = in.readString();
        image = in.readInt();
        serial_number = in.readInt();
    }

    public static final Creator<Auto> CREATOR = new Creator<Auto>() {
        @Override
        public Auto createFromParcel(Parcel in) {
            return new Auto(in);
        }

        @Override
        public Auto[] newArray(int size) {
            return new Auto[size];
        }
    };

    public int getSerial_number() {
        return serial_number;
    }

    public void setSerial_number(int serial_number) {
        this.serial_number = serial_number;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeInt(image);
        dest.writeInt(serial_number);
    }
}