package com.codingwithmitch.swipingviewpager.resources;

import com.codingwithmitch.swipingviewpager.R;
import com.codingwithmitch.swipingviewpager.models.Auto;



public class Autos {

    public static Auto[] getAuto(){
        return AUTOS;
    }

    public static final Auto BMW = new Auto("BMW Страна:Швеция", R.drawable.bmw);
    public static final Auto FERRARI = new Auto("FERRARI Страна:Италия", R.drawable.ferrari);
    public static final Auto FORD = new Auto("FORD Страна:Швеция", R.drawable.ford);
    public static final Auto ISUZU = new Auto("ISUZU Страна:Украина", R.drawable.isuzu);
    public static final Auto MAN = new Auto("MAN Страна:Италия", R.drawable.man);
    public static final Auto MERCEDES = new Auto("MERCEDES Страна:Франция", R.drawable.mercedes);
    public static final Auto SCANIA = new Auto("SCANIA  Страна:Бельгия", R.drawable.scania);
    public static final Auto SETRA = new Auto("SETRA Страна:Бельгия", R.drawable.setra);
    public static final Auto TOYOTA = new Auto("TOYOTA Страна:Япония", R.drawable.toyota);
    public static final Auto VOLVO = new Auto("VOLVO Страна:Югославия", R.drawable.volvo);

    public static final Auto[] AUTOS = {BMW, FERRARI, FORD, ISUZU, MAN, MERCEDES, SCANIA, SETRA, TOYOTA, VOLVO};



}