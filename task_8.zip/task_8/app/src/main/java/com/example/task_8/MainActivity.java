package com.example.task_8;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView txtView, txtOp;
    ImageView imgVw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.example_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
 int id=item.getItemId();
        switch (id){
            case R.id.item1:
                return true;
                case R.id.subitem1:
                    show();
                    txtView.setText("Volvo XC60 Страна:Швеция");
                    imgVw.setImageDrawable(null);
                    imgVw.setImageResource(R.drawable.volvo);
                    return true;

                case R.id.subitem2:
                    show();
                    txtView.setText("SCANIA R 730 Страна:Швеция");
                    imgVw.setImageDrawable(null);
                    imgVw.setImageResource(R.drawable.scania);
                    return true;

                case R.id.subitem3:
                    show();
                    txtView.setText("MAN Страна:Германия");
                    imgVw.setImageDrawable(null);
                    imgVw.setImageResource(R.drawable.man);
                    return true;

            case R.id.item2:
                return true;

                case R.id.subitem11:
                     show();
                    txtView.setText("Setra S 517 HDH Страна:Франция");
                    imgVw.setImageDrawable(null);
                    imgVw.setImageResource(R.drawable.setra);
                    return true;

                case R.id.subitem12:
                    show();
                    txtView.setText("Mercedes Travego Страна: Турция");
                    imgVw.setImageDrawable(null);
                    imgVw.setImageResource(R.drawable.mercedes);
                    return true;

                case R.id.subitem13:
                    show();
                    txtView.setText("ISUZU-БОГДАН А092 Страна:  Украина");
                    imgVw.setImageDrawable(null);
                    imgVw.setImageResource(R.drawable.isuzu);
                    return true;

            case R.id.item3:
                return true;
                case R.id.subitem21:
                    show();
                    txtView.setText("BMW X4 at Geneva Motorshow 2018 Страна:США");
                    imgVw.setImageDrawable(null);
                    imgVw.setImageResource(R.drawable.bmw);
                    return true;

                case R.id.subitem22:
                    show();
                    txtView.setText("Ford Galaxy Titanium  Страна: Бельгия");
                    imgVw.setImageDrawable(null);
                    imgVw.setImageResource(R.drawable.ford);
                    return true;

                case R.id.subitem23:
                    show();
                    txtView.setText("Toyota GR Yaris Страна:Франция");
                    imgVw.setImageDrawable(null);
                    imgVw.setImageResource(R.drawable.toyota);
                    return true;


            default:return super.onOptionsItemSelected(item);
        }
    }
void init(){
   txtOp=(TextView) findViewById(R.id.txtOpen);
txtView=(TextView) findViewById(R.id.txtInfo);
imgVw=(ImageView) findViewById(R.id.imageView);
}

void show(){
        txtOp.setVisibility(View.GONE);
        txtView.setVisibility(View.VISIBLE);
        imgVw.setVisibility(View.VISIBLE);

}


}